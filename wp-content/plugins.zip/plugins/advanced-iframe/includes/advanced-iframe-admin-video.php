<?php if ($devOptions['accordeon_menu'] == 'false') { ?>
<div class="ai-anchor" id="vi"></div>
<?php } ?>
<h1><?php _e('Video tutorials', 'advanced-iframe'); ?></h1>
<div>
    <div id="icon-options-general" class="icon_ai">
      <br />
    </div> <h2>
<?php _e('Video tutorials', 'advanced-iframe'); ?>       </h2>
    <p>
    <?php _e('The videos are not included in the plugin directly as they will be extended soon on the website.' , 'advanced-iframe'); ?></p><p>
      <a href="http://www.tinywebgallery.com/blog/advanced-iframe/advanced-iframe-video-tutorials" target="_blank" id="vid" class="button-primary"><?php _e('Go to the video tutorials' , 'advanced-iframe'); ?></a>    
    </p>
</div> 