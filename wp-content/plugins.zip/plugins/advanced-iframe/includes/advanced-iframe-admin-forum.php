<?php if ($devOptions['accordeon_menu'] == 'false') { ?>
<div class="ai-anchor" id="fo"></div>
<?php } ?>
<h1><?php _e('Forum', 'advanced-iframe'); ?></h1>
<div>
    <div id="icon-options-general" class="icon_ai">
      <br />
    </div> <h2>
<?php _e('Forum', 'advanced-iframe'); ?>       </h2>
    <p>
      <?php _e('Please use the forum for support. Make sure to enable the "Check shortcode" on the introduction tab first as this maybe already show you which setting is not valid!' , 'advanced-iframe'); ?></p><p>
      <a href="http://www.tinywebgallery.com/en/forum.php" target="_blank" id="faq" class="button-primary"><?php _e('Go to the forum' , 'advanced-iframe'); ?></a>    
    </p>
</div> 