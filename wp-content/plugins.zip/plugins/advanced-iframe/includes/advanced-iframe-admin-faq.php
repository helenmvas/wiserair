<?php if ($devOptions['accordeon_menu'] == 'false') { ?>
<div class="ai-anchor" id="vi"></div>
<?php } ?>
<h1><?php _e('FAQ', 'advanced-iframe'); ?></h1>
<div>
    <div id="icon-options-general" class="icon_ai">
      <br />
    </div> <h2>
<?php _e('FAQ', 'advanced-iframe'); ?>       </h2>
    <p>
      <?php _e('The FAQ is not included in the plugin directly as it is updated frequently on the website.' , 'advanced-iframe'); ?></p><p>
      <a href="http://www.tinywebgallery.com/blog/advanced-iframe/advanced-iframe-faq" target="_blank" id="faq" class="button-primary"><?php _e('Go to the FAQ' , 'advanced-iframe'); ?></a>    
    </p>
</div> 