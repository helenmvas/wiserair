=== Category Wise Search ===
Contributors: shambhu patnaik
Donate link: http://socialcms.wordpress.com/
Tags: category wise search widget,widget,search,search by category,exclude search category,filter search,search widget,search filter,search by category,category,category wise search
Requires at least: 2.9
Tested up to: 4.4
Stable tag: 1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Category Wise Search Widget plugin.You have option search specific category content.

== Description ==

Category Wise Search Widget plugin.You have option search specific category content.

**Features**

- Search post category wise.
- Set default category.
- Exclude categories in search category field.
- Exclude categories with child in search category field.

More detail : http://socialcms.wordpress.com/


== Installation ==


1. Upload the category-wise-search folder to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go Appearance => widgets section  see **Category Wise Search**

== Frequently Asked Questions ==

N/A

== Screenshots ==

1. screenshot-1.png  : screen shot admin widgets section.


== Changelog ==

= 1.3 =
* Add exclude category  with its childs option in category list

= 1.2.1 =
* fix category display order.

= 1.2 =
* Add exclude category option in category list.

= 1.1 =
* Add default select option 

= 1.0 =
* Initial release

== Upgrade Notice ==

N/A