jQuery(document).ready(function($)
	{
		//Scripts goes here


	});	






